import 'package:dashgc/playerView_model.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class PlayerView extends HookConsumerWidget {
  @override
  Widget build(Object context, WidgetRef ref) {
    final provider = ref.watch(stateProvider);
    return Scaffold(
      backgroundColor: provider.scafoldcolr,
      appBar: AppBar(
        backgroundColor: provider.appbarcolr,
        title: const Text('Play App'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Press + Button To Play Sound:',
              style: TextStyle(
                  color: Colors.greenAccent, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          provider.add();
        },
        child: const Icon(Icons.play_arrow),
      ),
    );
  }
}
