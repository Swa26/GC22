import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:audioplayers/audioplayers.dart';

final stateProvider =
    ChangeNotifierProvider<CounterViewModel>((ref) => CounterViewModel());

class CounterViewModel extends ChangeNotifier {
  int _counter = 0;
  final note = '1.m4a';
  Color appbarcolr = Colors.black;
  Color scafoldcolr = Colors.white;
  final player = AudioPlayer();
  int get counter => _counter;
  void add() {
    appbarcolr = Colors.yellow;
    scafoldcolr = Colors.black;
    player.play(AssetSource(note));

    notifyListeners();
  }
}
