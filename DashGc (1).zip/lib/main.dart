import 'package:dashgc/player_view.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

void main() => runApp(ProviderScope(child: MyApp()));

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: PlayerView(),
    );
  }
}

/*class MyApp extends StatelessWidget {
  const MyApp({super.key});
  static const String _title = 'Play App';
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(
        note: '10.m4a',
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  final note;
  const MyHomePage({super.key, this.note});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  Color appbarcolr = Colors.black;
  Color scafoldcolr = Colors.white;

  final player = AudioPlayer();
  void _incrementCounter() {
    setState(() {
      appbarcolr = Colors.yellow;
      scafoldcolr = Colors.black;
      player.play(AssetSource(widget.note));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: scafoldcolr,
      appBar: AppBar(
        backgroundColor: appbarcolr,
        title: const Text('Play App'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Press + Button To Play Sound:',
              style: TextStyle(
                  color: Colors.greenAccent, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.play_arrow),
      ),
    );
  }
}*/
