package com.example.dashgc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
